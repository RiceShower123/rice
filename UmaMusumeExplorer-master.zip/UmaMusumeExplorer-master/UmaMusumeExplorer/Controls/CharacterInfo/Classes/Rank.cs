﻿namespace UmaMusumeExplorer.Controls.CharacterInfo.Classes
{
    public enum Rank
    {
        Unknown,
        G,
        F,
        E,
        D,
        C,
        B,
        A,
        S
    }
}
