﻿namespace UmaMusumeExplorer.Controls.RaceMusicPlayer.Classes
{
    public class Pattern
    {
        public int BgmTime { get; set; }

        public string BgmCueName { get; set; } = "";

        public string BgmCuesheetName { get; set; } = "";
    }
}
