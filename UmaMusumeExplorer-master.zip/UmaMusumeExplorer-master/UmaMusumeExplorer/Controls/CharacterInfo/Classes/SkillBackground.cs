﻿namespace UmaMusumeExplorer.Controls.CharacterInfo.Classes
{
    public enum SkillBackground
    {
        Rarity1 = 1,
        Rarity2 = 2,
        Rarity3 = 3,
        Rarity4 = 4,
        Rarity5 = 5,
        Evolution = 6
    }
}
