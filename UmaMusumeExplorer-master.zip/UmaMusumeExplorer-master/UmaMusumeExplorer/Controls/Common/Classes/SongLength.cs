﻿namespace UmaMusumeExplorer.Controls.Common.Classes
{
    public enum SongLength
    {
        ShortVersion,
        GameSizeVersion
    }
}
