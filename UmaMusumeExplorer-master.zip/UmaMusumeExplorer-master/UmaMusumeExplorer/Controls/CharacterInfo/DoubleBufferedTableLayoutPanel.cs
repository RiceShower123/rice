﻿namespace UmaMusumeExplorer.Controls.CharacterInfo
{
    internal class DoubleBufferedTableLayoutPanel : TableLayoutPanel
    {
        public DoubleBufferedTableLayoutPanel()
        {
            DoubleBuffered = true;
        }
    }
}
